<?php 
require_once 'db_connect.php'; 

// --- 1. Initialize Variables and Determine Active Tab ---
$active_tab = $_GET['tab'] ?? 'schedule'; // Default to 'schedule'
$success_message = "";
$error_message = "";

// Function to safely redirect
function redirect_to($url) {
    header("Location: $url");
    exit();
}

// --- 2. Handle POST Submissions with Redirects ---

// 1. Handle Schedule Enrollment
if (isset($_POST['add_schedule'])) {
    $student_id = $conn->real_escape_string($_POST['student_id']);
    $subject_id = $conn->real_escape_string($_POST['subject_id']);
    $room_id = $conn->real_escape_string($_POST['room_id']);
    $day = $conn->real_escape_string($_POST['day']);
    $start = $conn->real_escape_string($_POST['start_time']);
    $end = $conn->real_escape_string($_POST['end_time']);

    $conn->query("INSERT IGNORE INTO enrollment (StudentID, SubjectID) VALUES ('$student_id', '$subject_id')");
    $sql = "INSERT INTO student_subject_schedule (StudentID, SubjectID, RoomID, DayOfWeek, StartTime, EndTime) 
            VALUES ('$student_id', '$subject_id', '$room_id', '$day', '$start', '$end')";
    
    if ($conn->query($sql)) {
        redirect_to("enroll_student.php?status=schedule_added&tab=schedule");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Error adding schedule: " . $conn->error));
    }
}

// 2. Handle Add Subject
if (isset($_POST['add_subject'])) {
    $sub = $conn->real_escape_string($_POST['subject_name']);
    $sql = "INSERT INTO subject (SubjectName) VALUES ('$sub')";
    if ($conn->query($sql)) {
        redirect_to("enroll_student.php?status=subject_added&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Error adding subject: " . $conn->error));
    }
}

// 3. Handle Add Room
if (isset($_POST['add_room'])) {
    $room = $conn->real_escape_string($_POST['room_name']);
    $sql = "INSERT INTO room (RoomName) VALUES ('$room')";
    if ($conn->query($sql)) {
        redirect_to("enroll_student.php?status=room_added&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Error adding room: " . $conn->error));
    }
}

// 4. Handle Delete Subject
if (isset($_POST['delete_subject_id'])) {
    $id = $conn->real_escape_string($_POST['delete_subject_id']);
    if ($conn->query("DELETE FROM subject WHERE SubjectID = '$id'")) {
        redirect_to("enroll_student.php?status=deleted&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Deletion failed. Subject might be used in schedules."));
    }
}

// 5. Handle Delete Room
if (isset($_POST['delete_room_id'])) {
    $id = $conn->real_escape_string($_POST['delete_room_id']);
    if ($conn->query("DELETE FROM room WHERE RoomID = '$id'")) {
        redirect_to("enroll_student.php?status=deleted&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Deletion failed. Room might be used in schedules."));
    }
}

// 6. Handle Add Department (NEW)
if (isset($_POST['add_department'])) { 
    $dept = $conn->real_escape_string($_POST['dept_name']);
    if ($conn->query("INSERT INTO department (DepartmentName) VALUES ('$dept')")) {
        redirect_to("enroll_student.php?status=department_added&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Error adding department: " . $conn->error));
    }
}

// 7. Handle Delete Department (NEW)
if (isset($_POST['delete_department_id'])) { 
    $id = $conn->real_escape_string($_POST['delete_department_id']);
    if ($conn->query("DELETE FROM department WHERE DepartmentID = '$id'")) {
        redirect_to("enroll_student.php?status=deleted&tab=manage");
    } else {
        redirect_to("enroll_student.php?status=error&message=" . urlencode("Deletion failed. Department might be used."));
    }
}


// Check for status messages after a redirect
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'schedule_added') {
        $success_message = "Schedule Added Successfully!";
    } elseif ($_GET['status'] == 'subject_added') {
        $success_message = "Subject added successfully!";
    } elseif ($_GET['status'] == 'room_added') {
        $success_message = "Room added successfully!";
    } elseif ($_GET['status'] == 'department_added') {
        $success_message = "Department added successfully!";
    } elseif ($_GET['status'] == 'deleted') {
        $success_message = "Item successfully deleted.";
    } elseif ($_GET['status'] == 'error') {
        $error_message = $_GET['message'] ?? "An unknown error occurred.";
    }
}

// Fetch lists (must be done after processing POST data)
$students = $conn->query("SELECT ID, FirstName, LastName FROM student ORDER BY LastName");
$subjects = $conn->query("SELECT * FROM subject ORDER BY SubjectName");
$rooms = $conn->query("SELECT * FROM room ORDER BY RoomName");
$departments = $conn->query("SELECT * FROM department ORDER BY DepartmentName"); // New Fetch
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enroll Student Schedule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-4">
        <h2 class="mb-4 text-primary">📚 Schedule Management</h2>

        <?php
        // Display messages
        if ($success_message) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'><strong>Success!</strong> $success_message<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button></div>";
        }
        if ($error_message) {
            echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'><strong>Error!</strong> $error_message<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button></div>";
        }
        ?>
        
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link <?php echo ($active_tab == 'schedule' ? 'active' : ''); ?>" 
                        id="schedule-tab" 
                        data-bs-toggle="tab" 
                        data-bs-target="#schedule-content" 
                        type="button" 
                        role="tab" 
                        aria-controls="schedule-content" 
                        aria-selected="<?php echo ($active_tab == 'schedule' ? 'true' : 'false'); ?>">Set Student Schedule</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?php echo ($active_tab == 'manage' ? 'active' : ''); ?>" 
                        id="manage-tab" 
                        data-bs-toggle="tab" 
                        data-bs-target="#manage-content" 
                        type="button" 
                        role="tab" 
                        aria-controls="manage-content" 
                        aria-selected="<?php echo ($active_tab == 'manage' ? 'true' : 'false'); ?>">Manage Subjects, Rooms & Departments</button>
            </li>
        </ul>
        
        <div class="tab-content border border-top-0 p-3 bg-white shadow-sm" id="myTabContent">
            <div class="tab-pane fade <?php echo ($active_tab == 'schedule' ? 'show active' : ''); ?>" id="schedule-content" role="tabpanel" aria-labelledby="schedule-tab">
                <h3 class="mb-3">Set Student Schedule</h3>
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6 mb-3">
                            <label for="student_id" class="form-label">Student:</label>
                            <select class="form-select" name="student_id" id="student_id" required>
                                <option value="">Select Student</option>
                                <?php $students->data_seek(0); while($row = $students->fetch_assoc()) { 
                                    echo "<option value='{$row['ID']}'>{$row['LastName']}, {$row['FirstName']}</option>";
                                } ?>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="subject_id" class="form-label">Subject:</label>
                            <select class="form-select" name="subject_id" id="subject_id" required>
                                <option value="">Select Subject</option>
                                <?php 
                                $subjects->data_seek(0); 
                                while($row = $subjects->fetch_assoc()) {
                                    echo "<option value='{$row['SubjectID']}'>{$row['SubjectName']}</option>";
                                } ?>
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="room_id" class="form-label">Room:</label>
                            <select class="form-select" name="room_id" id="room_id" required>
                                <option value="">Select Room</option>
                                <?php 
                                $rooms->data_seek(0);
                                while($row = $rooms->fetch_assoc()) {
                                    echo "<option value='{$row['RoomID']}'>{$row['RoomName']}</option>";
                                } ?>
                            </select>
                        </div>

                        <div class="col-md-3 mb-3">
                            <label for="day" class="form-label">Day of Week:</label>
                            <select class="form-select" name="day" id="day">
                                <option>Monday</option><option>Tuesday</option><option>Wednesday</option>
                                <option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option>
                            </select>
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label for="start_time" class="form-label">Start Time:</label>
                            <input type="time" class="form-control" name="start_time" id="start_time" required>
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label for="end_time" class="form-label">End Time:</label>
                            <input type="time" class="form-control" name="end_time" id="end_time" required>
                        </div>

                        <div class="col-12 mt-3">
                            <button type="submit" name="add_schedule" class="btn btn-primary">Add to Schedule</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="tab-pane fade <?php echo ($active_tab == 'manage' ? 'show active' : ''); ?>" id="manage-content" role="tabpanel" aria-labelledby="manage-tab">
                <div class="row g-4">
                    
                    <div class="col-md-4">
                        <div class="card bg-light h-100">
                            <div class="card-header bg-success text-white">
                                <h4>🏢 Department Management</h4>
                            </div>
                            <div class="card-body">
                                <h5 class="mb-3">Quick Add Department</h5>
                                <form method="POST" class="mb-4">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="dept_name" placeholder="Department Name (e.g., SIT)" required>
                                        <button class="btn btn-primary" type="submit" name="add_department">Add Department</button>
                                    </div>
                                </form>
                                
                                <h5>Available Departments:</h5>
                                <?php 
                                $departments->data_seek(0);
                                if ($departments->num_rows > 0) {
                                    echo '<div class="list-group">';
                                    while($row = $departments->fetch_assoc()) {
                                        echo '<div class="list-group-item d-flex justify-content-between align-items-center">';
                                        echo '<span>' . htmlspecialchars($row['DepartmentName']) . '</span>';
                                        echo '<form method="POST" onsubmit="return confirm(\'WARNING: Deleting this department will set the DepartmentID to NULL for all associated students. Are you sure?\')">';
                                        echo '<input type="hidden" name="delete_department_id" value="' . $row['DepartmentID'] . '">';
                                        echo '<button type="submit" class="btn btn-sm btn-danger">Delete</button>';
                                        echo '</form>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                } else {
                                    echo '<div class="alert alert-info mt-2">No departments added yet.</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card bg-light h-100">
                            <div class="card-header bg-primary text-white">
                                <h4>📚 Subject Management</h4>
                            </div>
                            <div class="card-body">
                                <h5 class="mb-3">Quick Add Subject</h5>
                                <form method="POST" class="mb-4">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="subject_name" placeholder="Subject Name (e.g., MATH)" required>
                                        <button class="btn btn-success" type="submit" name="add_subject">Add Subject</button>
                                    </div>
                                </form>
                                
                                <h5>Available Subjects:</h5>
                                <?php 
                                $subjects->data_seek(0);
                                if ($subjects->num_rows > 0) {
                                    echo '<div class="list-group">';
                                    while($row = $subjects->fetch_assoc()) {
                                        echo '<div class="list-group-item d-flex justify-content-between align-items-center">';
                                        echo '<span>' . htmlspecialchars($row['SubjectName']) . '</span>';
                                        echo '<form method="POST" onsubmit="return confirm(\'WARNING: Deleting this subject will also delete related schedules/enrollments. Are you sure?\')">';
                                        echo '<input type="hidden" name="delete_subject_id" value="' . $row['SubjectID'] . '">';
                                        echo '<button type="submit" class="btn btn-sm btn-danger">Delete</button>';
                                        echo '</form>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                } else {
                                    echo '<div class="alert alert-info mt-2">No subjects added yet.</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card bg-light h-100">
                            <div class="card-header bg-danger text-white">
                                <h4>🚪 Room Management</h4>
                            </div>
                            <div class="card-body">
                                <h5 class="mb-3">Quick Add Room</h5>
                                <form method="POST" class="mb-4">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="room_name" placeholder="Room Name (e.g., F212)" required>
                                        <button class="btn btn-success" type="submit" name="add_room">Add Room</button>
                                    </div>
                                </form>
                                
                                <h5>Available Rooms:</h5>
                                <?php 
                                $rooms->data_seek(0);
                                if ($rooms->num_rows > 0) {
                                    echo '<div class="list-group">';
                                    while($row = $rooms->fetch_assoc()) {
                                        echo '<div class="list-group-item d-flex justify-content-between align-items-center">';
                                        echo '<span>' . htmlspecialchars($row['RoomName']) . '</span>';
                                        echo '<form method="POST" onsubmit="return confirm(\'WARNING: Deleting this room will also delete related schedules. Are you sure?\')">';
                                        echo '<input type="hidden" name="delete_room_id" value="' . $row['RoomID'] . '">';
                                        echo '<button type="submit" class="btn btn-sm btn-danger">Delete</button>';
                                        echo '</form>';
                                        echo '</div>';
                                    }
                                    echo '</div>';
                                } else {
                                    echo '<div class="alert alert-info mt-2">No rooms added yet.</div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>