<?php
// We reuse db_connect.php
require_once 'db_connect.php'; 

// Set Timezone to Asia/Manila for accurate comparison against EndTime
date_default_timezone_set('Asia/Manila');

$today = date('Y-m-d');
$time_now = date('H:i:s');
$results = [
    'date' => $today,
    'current_time' => $time_now,
    'absent_students_marked' => 0,
    'errors' => []
];

// 1. Find all student schedules for today that have already ended
// We also need the StudentID from the schedule table
$sql_ended_schedules = "
    SELECT 
        sss.StudentScheduleID, 
        sss.StudentID, 
        sss.SubjectID, 
        sss.EndTime 
    FROM student_subject_schedule sss
    WHERE sss.DayOfWeek = DATE_FORMAT(NOW(), '%W') 
      AND sss.EndTime <= '{$time_now}'
";

$ended_schedules_result = $conn->query($sql_ended_schedules);

if ($ended_schedules_result && $ended_schedules_result->num_rows > 0) {
    
    while ($schedule = $ended_schedules_result->fetch_assoc()) {
        $sched_id = $schedule['StudentScheduleID'];
        $student_id = $schedule['StudentID'];
        $subject_id = $schedule['SubjectID'];

        // 2. Check if the student already has an attendance record for this schedule today
        $check_attendance_sql = "
            SELECT AttendanceID 
            FROM attendance 
            WHERE StudentID = '{$student_id}' 
              AND StudentScheduleID = '{$sched_id}' 
              AND Date = '{$today}'
        ";
        
        $check_result = $conn->query($check_attendance_sql);

        // 3. If NO record exists, mark them Absent
        if ($check_result->num_rows == 0) {
            $insert_absent_sql = "
                INSERT INTO attendance (StudentScheduleID, StudentID, SubjectID, Date, TimeIn, Status) 
                VALUES ('{$sched_id}', '{$student_id}', '{$subject_id}', '{$today}', NULL, 'Absent')
            ";
            
            if ($conn->query($insert_absent_sql)) {
                $results['absent_students_marked']++;
            } else {
                $results['errors'][] = "Error marking student {$student_id} (Schedule {$sched_id}) absent: " . $conn->error;
            }
        }
    }
} else {
    $results['message'] = "No schedules have ended yet today at {$time_now} or no schedules found for " . date('l') . ".";
}

// Optional: Output the results for debugging if running manually
// echo "<pre>" . print_r($results, true) . "</pre>";
// Close the database connection (optional, PHP will do this, but good practice)
$conn->close();

?>