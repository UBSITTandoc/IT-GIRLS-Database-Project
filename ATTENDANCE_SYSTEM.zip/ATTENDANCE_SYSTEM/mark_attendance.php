<?php require_once 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-4">
        <h2 class="mb-4 text-center text-success">✅ Check and Mark Attendance</h2>

        <div class="card shadow-sm mb-4">
            <div class="card-header bg-light">
                <h4 class="mb-0">🔍 Search Student</h4>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-center">
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="search" placeholder="Enter Student Number or Last Name (e.g., 20232551)" required value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-success w-100">Search Student</button>
                    </div>
                </form>
            </div>
        </div>

        <?php
        if (isset($_GET['search'])) {
            $search = $conn->real_escape_string($_GET['search']);
            
            // Find Student by StudentNumber OR LastName
            $student_sql = "SELECT s.*, d.DepartmentName 
                            FROM student s 
                            LEFT JOIN department d ON s.DepartmentID = d.DepartmentID 
                            WHERE s.StudentNumber = '$search' OR s.LastName LIKE '%$search%' LIMIT 1";
            $student_res = $conn->query($student_sql);
            $student = $student_res->fetch_assoc();

            if ($student) {
                ?>
                <div class="card mb-4 shadow">
                    <div class="card-header bg-info text-white">
                        <h4 class="mb-0">Student Found: <?php echo htmlspecialchars($student['FirstName'] . ' ' . $student['LastName']); ?> 
                            (ID: <?php echo $student['ID']; ?> | Number: <?php echo $student['StudentNumber'] ?? 'N/A'; ?>)
                        </h4>
                        <small>Department: <?php echo htmlspecialchars($student['DepartmentName'] ?? 'N/A'); ?></small>
                    </div>
                    <div class="card-body">
                        <?php
                        // Handle Attendance Submission (unchanged logic)
                        if (isset($_POST['mark_attendance'])) {
                            // ... (Attendance submission logic remains the same) ...
                            // ... (Sanitization and INSERT/UPDATE logic) ...
                            $sched_id = $conn->real_escape_string($_POST['schedule_id']);
                            $status = $conn->real_escape_string($_POST['status']);
                            $sid = $conn->real_escape_string($student['ID']);
                            $sub_id = $conn->real_escape_string($_POST['subject_id']);
                            $today = date('Y-m-d');
                            $time_now = date('H:i:s');

                            $check_sql = "SELECT AttendanceID FROM attendance WHERE StudentID = '$sid' AND StudentScheduleID = '$sched_id' AND Date = '$today'";
                            $check_res = $conn->query($check_sql);

                            if ($check_res->num_rows > 0) {
                                $upd = "UPDATE attendance SET Status = '$status', TimeIn = '$time_now' WHERE StudentID = '$sid' AND StudentScheduleID = '$sched_id' AND Date = '$today'";
                            } else {
                                $upd = "INSERT INTO attendance (StudentScheduleID, StudentID, SubjectID, Date, TimeIn, Status) 
                                        VALUES ('$sched_id', '$sid', '$sub_id', '$today', '$time_now', '$status')";
                            }
                            
                            if($conn->query($upd)) {
                                echo "<div class='alert alert-success'>Attendance marked as {$status} at " . date('h:i:s A') . "!</div>";
                            } else {
                                echo "<div class='alert alert-danger'>Error marking attendance: " . $conn->error . "</div>";
                            }
                        }

                        // Show Student's Schedule (unchanged logic, uses internal ID)
                        echo "<h5>Select Class to Mark Attendance Today:</h5>";
                        $sql_sched = "SELECT sss.StudentScheduleID, sss.SubjectID, sub.SubjectName, sss.DayOfWeek, sss.StartTime, sss.EndTime, r.RoomName
                                      FROM student_subject_schedule sss
                                      JOIN subject sub ON sss.SubjectID = sub.SubjectID
                                      JOIN room r ON sss.RoomID = r.RoomID
                                      WHERE sss.StudentID = {$student['ID']}
                                      ORDER BY FIELD(sss.DayOfWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), sss.StartTime ASC";
                        
                        $schedules = $conn->query($sql_sched);
                        
                        if ($schedules->num_rows > 0) {
                            echo "<div class='table-responsive'>";
                            echo "<table class='table table-bordered table-sm'>";
                            echo "<thead class='table-secondary'><tr><th>Subject</th><th>Room</th><th>Day/Time</th><th>Action</th></tr></thead>";
                            echo "<tbody>";
                            while ($row = $schedules->fetch_assoc()) {
                                $time_in_display = date("h:i A", strtotime($row['StartTime']));
                                $time_out_display = date("h:i A", strtotime($row['EndTime']));
                                
                                echo "<tr>";
                                echo "<td>{$row['SubjectName']}</td>";
                                echo "<td>{$row['RoomName']}</td>";
                                echo "<td>{$row['DayOfWeek']} ({$time_in_display} - {$time_out_display})</td>";
                                echo "<td>
                                        <form method='POST' class='d-flex align-items-center' style='gap:10px;'>
                                            <input type='hidden' name='schedule_id' value='{$row['StudentScheduleID']}'>
                                            <input type='hidden' name='subject_id' value='{$row['SubjectID']}'>
                                            <select name='status' class='form-select form-select-sm'>
                                                <option value='Present'>Present</option>
                                                <option value='Late'>Late</option>
                                                <option value='Absent'>Absent</option>
                                            </select>
                                            <button type='submit' name='mark_attendance' class='btn btn-sm btn-primary text-nowrap'>Mark Now</button>
                                        </form>
                                      </td>";
                                echo "</tr>";
                            }
                            echo "</tbody></table>";
                            echo "</div>";
                        } else {
                            echo "<div class='alert alert-warning'>No schedule found for this student.</div>";
                        }
                        ?>
                    </div>
                </div>
                <?php
            } else {
                echo "<div class='alert alert-danger'>Student not found. Please check the Student Number or last name.</div>";
            }
        }
        ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>